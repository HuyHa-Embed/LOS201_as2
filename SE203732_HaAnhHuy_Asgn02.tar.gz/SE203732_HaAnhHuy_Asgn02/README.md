# ASSIGNMENT-02: Sensor Monitoring System (SMS)

Ha Anh Huy - SE203732. Embedded Linux Systems, ARMv7 QEMU vexpress-a9, kernel 5.15.

- `driver/`  kernel module `sms_sensor_driver` (`/dev/sms_sensor`, `/proc/sms_stats`, ioctl)
- `app/`     `sms_app` (4 pthreads + circular buffer + POSIX mq), `make arm host debug`
- `output/`  `zImage`, `.dtb`, `initramfs_asgn2.cpio.gz` (boots on QEMU)
- `logs/`    evidence: Valgrind/Helgrind, GDB sessions, strace, perf, jitter reports
- `bao_cao/` technical report (PDF + Markdown source); `demo/` demo video (replay of real logs)
- `tools/`   test/build scripts (`run_all_tests.sh`, `run_root_parts.sh`, `build_report.py`)
