# Kich ban A - race condition: quan sat head/tail/size cua shared_buffer
set pagination off
set confirm off
set debuginfod enabled off
set print pretty off
set architecture arm
set sysroot /home/huy/embedded_asgn2/rootfs/initramfs
file /home/huy/embedded_asgn2/app/sms_app_dbg
target remote localhost:1234
echo \n=== A1: breakpoint trong Processor Thread, tai cho doc shared_buffer (circular_buffer.c:83) ===\n
break circular_buffer.c:83
continue
continue
info threads
bt
print cb->head
print cb->tail
print cb->size
print cb->capacity
print cb->total_produced
print cb->total_consumed
echo \n=== A2: Sensor Thread dang ghi (cb_push), xem tat ca thread ===\n
delete
break circular_buffer.c:55
continue
info threads
thread apply all bt
print *cb
print/x cb->lock
echo \n=== A3: scheduler-locking on: chi Sensor Thread chay, buoc qua doan ghi ===\n
set scheduler-locking on
print cb->head
print cb->size
next
next
next
print cb->head
print cb->size
print cb->total_produced
info threads
set scheduler-locking off
delete
echo \n=== A4: sau khi ghi, Processor Thread lay du lieu ===\n
break circular_buffer.c:83
continue
print cb->head
print cb->tail
print cb->size
print cb->total_consumed
delete
continue
