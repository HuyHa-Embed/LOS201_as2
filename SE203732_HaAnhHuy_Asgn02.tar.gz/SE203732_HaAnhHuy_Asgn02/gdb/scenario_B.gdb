# Kich ban B - alert logic: gia lap cam bien vuot nguong bang 'set variable'
set pagination off
set confirm off
set debuginfod enabled off
set architecture arm
set sysroot /home/huy/embedded_asgn2/rootfs/initramfs
file /home/huy/embedded_asgn2/app/sms_app_dbg
target remote localhost:1234
echo \n=== B1: breakpoint trong detect_anomalies (chi dung khi mau BINH THUONG T<30) ===\n
break processor_thread.c:24 if s->temperature < 30
echo \n=== B2: breakpoint trong Alert Thread ngay sau mq_timedreceive ===\n
break alert_thread.c:42 if n > 0
continue
echo \n--- dung o Processor Thread ---\n
info threads
bt
print s->temperature
print s->humidity
print cfg->temp_thr
print temperature
echo \n--- ep nhiet do = 45.0 ---\n
set variable temperature = 45.0
print temperature
print temperature > cfg->temp_thr
delete 1
continue
echo \n--- Alert Thread tinh day, nhan message tu alarm_queue ---\n
info threads
bt
print n
print a
print/d a.type
print a.value
print a.threshold
delete
continue
