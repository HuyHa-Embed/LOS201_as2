/*
 * sms_sensor.h - Shared kernel/user definitions for the SMS sensor driver
 * Author : Ha Anh Huy - SE203732
 * Date   : 2026-10-18
 */
#ifndef SMS_SENSOR_H
#define SMS_SENSOR_H

#include <linux/ioctl.h>

#define SMS_DEVICE_NAME     "sms_sensor"      /* /dev/sms_sensor */
#define SMS_PROC_NAME       "sms_stats"       /* /proc/sms_stats */
#define SMS_DRV_DEFAULT_INTERVAL_MS 100U
#define SMS_MIN_INTERVAL_MS     1U
#define SMS_MAX_INTERVAL_MS     60000U

#define SMS_IOC_MAGIC       'S'
/* Minimum time between two reads, in milliseconds. */
#define SMS_SET_INTERVAL    _IOW(SMS_IOC_MAGIC, 1, unsigned int)
#define SMS_GET_INTERVAL    _IOR(SMS_IOC_MAGIC, 2, unsigned int)

#endif /* SMS_SENSOR_H */
