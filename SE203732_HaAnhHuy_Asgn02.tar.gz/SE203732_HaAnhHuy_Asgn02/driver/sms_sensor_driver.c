/*
 * sms_sensor_driver.c - Simulated temperature/humidity sensor (misc char device)
 * Author : Ha Anh Huy - SE203732
 * Date   : 2026-10-18
 *
 *  /dev/sms_sensor : read() returns one CSV line "<timestamp_ms>,<temp>,<hum>\n"
 *                    temp in 15.00..45.00 C, humidity in 30.00..90.00 %
 *                    (generated with get_random_u32()).
 *                    Reads are rate-limited to one per 'interval_ms' (anchored
 *                    schedule, see sms_read); an early read blocks on an
 *                    hrtimer (O_NONBLOCK -> -EAGAIN).
 *  /proc/sms_stats : read_count, last_temperature, last_humidity, uptime.
 *  ioctl           : SMS_SET_INTERVAL / SMS_GET_INTERVAL.
 *
 * No floating point in the kernel: values are kept as hundredths (x100).
 * ktime_get_ms() does not exist in Linux 5.15, so we use
 * ktime_to_ms(ktime_get()) which is the same monotonic millisecond clock.
 */
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/miscdevice.h>
#include <linux/uaccess.h>
#include <linux/mutex.h>
#include <linux/random.h>
#include <linux/ktime.h>
#include <linux/hrtimer.h>
#include <linux/sched.h>
#include <linux/math64.h>
#include <linux/delay.h>
#include <linux/sched/signal.h>
#include <linux/proc_fs.h>
#include <linux/seq_file.h>
#include "sms_sensor.h"

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Ha Anh Huy - SE203732");
MODULE_DESCRIPTION("ASSIGNMENT-02: SMS simulated sensor driver");
MODULE_VERSION("1.0");

#define TEMP_MIN_X100   1500
#define TEMP_RANGE_X100 3001    /* 15.00 .. 45.00 */
#define HUM_MIN_X100    3000
#define HUM_RANGE_X100  6001    /* 30.00 .. 90.00 */

static DEFINE_MUTEX(sms_lock);
static unsigned int interval_ms = SMS_DRV_DEFAULT_INTERVAL_MS;
static unsigned long read_count;
static int  last_temp_x100, last_hum_x100;
static s64  next_ok_ns;         /* earliest time the next read may complete (ns) */
static s64  load_ms;            /* time the module was loaded       */
static struct proc_dir_entry *proc_entry;

static inline s64 now_ms(void)
{
	return ktime_to_ms(ktime_get());
}

static ssize_t sms_read(struct file *f, char __user *ubuf, size_t len, loff_t *off)
{
	char line[64];
	int n, t, h;
	s64 ts, wait_ns;
	unsigned int ivl;

	if (len < 40)
		return -EINVAL;

	for (;;) {
		if (mutex_lock_interruptible(&sms_lock))
			return -ERESTARTSYS;
		ivl     = interval_ms;
		wait_ns = next_ok_ns - ktime_get_ns();
		if (next_ok_ns == 0 || wait_ns <= 0)
			break;                      /* keep the lock, produce a sample */
		mutex_unlock(&sms_lock);
		if (f->f_flags & O_NONBLOCK)
			return -EAGAIN;
		/* hrtimer sleep: msleep() has 1-jiffy (10 ms at HZ=100) granularity,
		 * which would stretch the read period and add jitter. */
		{
			ktime_t to = ns_to_ktime(wait_ns);

			set_current_state(TASK_INTERRUPTIBLE);
			schedule_hrtimeout(&to, HRTIMER_MODE_REL);
			if (signal_pending(current))
				return -EINTR;
		}
	}

	t  = TEMP_MIN_X100 + (int)(get_random_u32() % TEMP_RANGE_X100);
	h  = HUM_MIN_X100  + (int)(get_random_u32() % HUM_RANGE_X100);
	{
		s64 now = ktime_get_ns();
		s64 step = (s64)ivl * NSEC_PER_MSEC;

		/*
		 * Anchored rate limit: the next slot is previous_slot + interval, NOT
		 * now + interval. If the slot were re-anchored at every read, a client
		 * polling with the same period would be pushed later by its own jitter
		 * on every cycle and could never catch up (cumulative drift, found in
		 * testing). When the client is late by more than one interval, re-sync.
		 */
		if (next_ok_ns == 0 || now - next_ok_ns >= step)
			next_ok_ns = now + step;
		else
			next_ok_ns += step;
		ts = div_s64(now, NSEC_PER_MSEC);
	}
	last_temp_x100 = t;
	last_hum_x100  = h;
	read_count++;
	mutex_unlock(&sms_lock);

	n = scnprintf(line, sizeof(line), "%lld,%d.%02d,%d.%02d\n",
		      ts, t / 100, t % 100, h / 100, h % 100);
	if (n > (int)len)
		n = (int)len;
	if (copy_to_user(ubuf, line, n))
		return -EFAULT;
	return n;
}

static long sms_ioctl(struct file *f, unsigned int cmd, unsigned long arg)
{
	unsigned int v;

	switch (cmd) {
	case SMS_SET_INTERVAL:
		if (copy_from_user(&v, (void __user *)arg, sizeof(v)))
			return -EFAULT;
		if (v < SMS_MIN_INTERVAL_MS || v > SMS_MAX_INTERVAL_MS)
			return -EINVAL;
		mutex_lock(&sms_lock);
		interval_ms = v;
		mutex_unlock(&sms_lock);
		return 0;
	case SMS_GET_INTERVAL:
		mutex_lock(&sms_lock);
		v = interval_ms;
		mutex_unlock(&sms_lock);
		return copy_to_user((void __user *)arg, &v, sizeof(v)) ? -EFAULT : 0;
	default:
		return -ENOTTY;
	}
}

static const struct file_operations sms_fops = {
	.owner          = THIS_MODULE,
	.read           = sms_read,
	.unlocked_ioctl = sms_ioctl,
	.llseek         = no_llseek,
};

static struct miscdevice sms_misc = {
	.minor = MISC_DYNAMIC_MINOR,
	.name  = SMS_DEVICE_NAME,
	.fops  = &sms_fops,
	.mode  = 0666,
};

static int sms_proc_show(struct seq_file *m, void *v)
{
	mutex_lock(&sms_lock);
	seq_printf(m, "read_count: %lu\n", read_count);
	seq_printf(m, "last_temperature: %d.%02d\n", last_temp_x100 / 100, last_temp_x100 % 100);
	seq_printf(m, "last_humidity: %d.%02d\n", last_hum_x100 / 100, last_hum_x100 % 100);
	seq_printf(m, "uptime_seconds: %lld\n", div_s64(now_ms() - load_ms, 1000));
	seq_printf(m, "interval_ms: %u\n", interval_ms);
	mutex_unlock(&sms_lock);
	return 0;
}

static int sms_proc_open(struct inode *inode, struct file *file)
{
	return single_open(file, sms_proc_show, NULL);
}

static const struct proc_ops sms_proc_ops = {
	.proc_open    = sms_proc_open,
	.proc_read    = seq_read,
	.proc_lseek   = seq_lseek,
	.proc_release = single_release,
};

static int __init sms_init(void)
{
	int ret = misc_register(&sms_misc);

	if (ret) {
		pr_err("sms_sensor: misc_register failed (%d)\n", ret);
		return ret;
	}
	proc_entry = proc_create(SMS_PROC_NAME, 0444, NULL, &sms_proc_ops);
	if (!proc_entry) {
		misc_deregister(&sms_misc);
		return -ENOMEM;
	}
	load_ms = now_ms();
	pr_info("sms_sensor: loaded, /dev/%s minor=%d interval=%ums\n",
		SMS_DEVICE_NAME, sms_misc.minor, interval_ms);
	return 0;
}

static void __exit sms_exit(void)
{
	proc_remove(proc_entry);
	misc_deregister(&sms_misc);
	pr_info("sms_sensor: unloaded (read_count=%lu)\n", read_count);
}

module_init(sms_init);
module_exit(sms_exit);
