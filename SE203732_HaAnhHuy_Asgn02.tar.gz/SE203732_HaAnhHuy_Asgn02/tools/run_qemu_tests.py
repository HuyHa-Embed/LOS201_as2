"""ASGN-02: bo kiem thu tren QEMU ARM (Task 1-4). Ket qua ghi vao logs/."""
import sys, os, re
sys.path.insert(0, os.path.expanduser('~/embedded_asgn2/tools'))
import qemu_session as q
H = os.path.expanduser('~/embedded_asgn2'); L = f'{H}/logs'

def clean(s):
    s = s.replace('\r', '')
    return re.sub(r'\x1b\[[0-9;]*m', '', s)

c = q.boot(f'{L}/qemu_asgn2_session.txt')
def r(cmd, t=300, save=None):
    out = clean(q.run(c, cmd, t))
    lines = out.split('\n')
    out = '\n'.join(lines[1:]) if lines and cmd[:20] in lines[0] else out   # bo dong echo lenh
    if save: open(f'{L}/{save}', 'w').write(out.strip('\n') + '\n')
    print(f'>>> {cmd[:90]}\n{out[-1500:]}')
    return out

r('uname -a; lsmod; dmesg | grep sms_sensor; ls -l /dev/sms_sensor', save='driver_load.txt')
r('cat /proc/sms_stats', save='proc_sms_stats_before.txt')

# --- Task 1/2: chay 60 s, do VmRSS/VmSize tai T=5/30/55, threads, maps ---
cmd = ('sms_app -d 60 -v -l /tmp/sms.log -j /tmp/jit_main.txt >/tmp/sms_stdout.txt 2>/tmp/sms_stderr.txt & P=$!; '
       'snap() { echo "== T=$1s =="; grep -E "VmSize|VmRSS|VmData|VmStk|Threads" /proc/$P/status; }; '
       'sleep 5; snap 5; '
       'echo "== threads =="; for t in /proc/$P/task/*; do echo "$(basename $t) $(cat $t/comm)"; done; '
       'echo "== fds =="; ls -l /proc/$P/fd | cut -c40-; '
       'echo "== sched sensor thread =="; for t in /proc/$P/task/*; do n=$(cat $t/comm); [ "$n" = sms_sensor ] && chrt -p $(basename $t); done; '
       'sleep 25; snap 30; echo "== maps T=30 =="; cat /proc/$P/maps > /tmp/maps30.txt; cat /tmp/maps30.txt; '
       'sleep 24; snap 55; wait $P; echo "exit=$?"')
out = r(cmd, 200, save='proc_status_samples.txt')
open(f'{L}/proc_maps_T30.txt', 'w').write(out.split('== maps T=30 ==')[1].split('== T=55s ==')[0].strip() + '\n')
r('cat /proc/sms_stats', save='proc_sms_stats_after.txt')
r('cat /tmp/sms_stdout.txt | tail -12', save='sms_summary_stdout.txt')
r('cat /tmp/sms_stdout.txt', 60, save='sms_sample_run.txt')
r('cat /tmp/sms_stderr.txt', 60, save='sms_alerts_stderr.txt')
r('cat /tmp/sms.log', 60, save='sms.log')
r('cut -d" " -f3 /tmp/sms.log | sort | uniq -c; ls -l /tmp/sms.log; cat /tmp/jit_main.txt', save='sms_log_stats.txt')

# --- SIGINT, error codes, rotation, module reload ---
r('sms_app -d 0 -l /tmp/sigint.log >/tmp/sigint_out.txt 2>/tmp/sigint_err.txt & P=$!; sleep 8; '
  'echo "fds before SIGINT:"; ls -l /proc/$P/fd | cut -c40-; kill -INT $P; wait $P; echo "exit_code=$?"; '
  'ls /proc/$P 2>&1 | head -2; cat /tmp/sigint_out.txt; tail -4 /tmp/sigint.log; grep -c "stopped" /tmp/sigint.log', 60, save='sigint_test.txt')
r('sms_app -D /dev/nonexistent -d 1 -l /tmp/e.log; echo "exit_code=$?"; sms_app -i 0; echo "exit_code=$?"; sms_app -p bogus; echo "exit_code=$?"', 60, save='error_codes_test.txt')
r('sms_app -i 50 -d 12 -m 30000 -l /tmp/rot.log >/dev/null 2>&1; ls -l /tmp/rot.log*; wc -l /tmp/rot.log*', 60, save='log_rotation_test.txt')
r('rmmod sms_sensor_driver; echo rmmod=$?; ls /dev/sms_sensor 2>&1; insmod /lib/modules/5.15.0/sms_sensor_driver.ko; echo insmod=$?; dmesg | tail -5; cat /proc/sms_stats', 60, save='module_reload_test.txt')

# --- Task 4: jitter SCHED_FIFO vs SCHED_OTHER (idle va co tai CPU) ---
def jit(tag, pol):
    return f'sms_app -i 10 -d 15 -p {pol} -l /tmp/j.log -j /tmp/jit_{tag}.txt >/dev/null 2>&1; cat /tmp/jit_{tag}.txt'
out = ''
for pol in ('fifo', 'other'):
    out += f'##### IDLE ({pol}) #####\n' + r(jit('idle_' + pol, pol), 100)
r('sh -c "while :; do :; done" & H1=$!; sh -c "while :; do :; done" & H2=$!; echo $H1 $H2 > /tmp/hogs')
for pol in ('fifo', 'other'):
    out += f'##### LOAD: 2 CPU hogs ({pol}) #####\n' + r(jit('load_' + pol, pol), 100)
r('kill $(cat /tmp/hogs)')
open(f'{L}/jitter_report.txt', 'w').write(out)

# --- strace (-c, co theo doi thread) 30 s va time ---
r('strace -c -f -o /tmp/strace_sms.txt sms_app -d 30 -l /tmp/st.log >/dev/null 2>&1; cat /tmp/strace_sms.txt', 100, save='strace_sms_arm.txt')
r('time sms_app -d 30 -l /tmp/st2.log >/dev/null 2>&1', 100, save='time_sms_arm.txt')
c.close(force=True)
