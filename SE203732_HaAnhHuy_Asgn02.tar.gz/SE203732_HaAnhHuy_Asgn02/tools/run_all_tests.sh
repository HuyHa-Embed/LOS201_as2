#!/bin/bash
# Chay lai toan bo kiem thu ASGN-02 (can QEMU, valgrind cuc bo). Ket qua trong logs/
cd ~/embedded_asgn2
source ~/embedded_lab3/tools/env.sh
(cd app && timeout -s INT 32 valgrind --leak-check=full --show-leak-kinds=all --track-origins=yes \
   --log-file=$HOME/embedded_asgn2/logs/valgrind_sms.txt ./sms_app_x86 -d 0 -p other -l /tmp/vg_sms.log >/tmp/vg_stdout.txt 2>/tmp/vg_stderr.txt)
(cd app && valgrind --tool=helgrind --log-file=$HOME/embedded_asgn2/logs/helgrind_sms.txt ./sms_app_x86 -d 15 -i 100 -p other -l /tmp/hg.log >/dev/null 2>&1)
python3 tools/run_qemu_tests.py > logs/run_qemu_tests_stdout.txt 2>&1
python3 tools/run_qemu_extra.py > logs/run_qemu_extra_stdout.txt 2>&1
python3 tools/run_gdb_sessions.py > logs/run_gdb_stdout.txt 2>&1
echo ALLDONE
