#!/usr/bin/env python3
"""Tao demo/SE203732_demo.mp4 (~4 phut) bang cach PHAT LAI cac log that cua phien chay
tren QEMU/GDB/Valgrind (khong phai quay man hinh truc tiep). Moi doan co chu thich."""
import os, re, subprocess, shutil, textwrap
from PIL import Image, ImageDraw, ImageFont

B = os.path.expanduser('~/embedded_asgn2'); L = f'{B}/logs'
W, H = 1280, 720
FONT = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf', 15)
BOLD = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf', 19)
CW, LH, COLS = 9, 18, 138
ROWS = (H - 90) // LH
FRAMES = f'/tmp/claude-1000/-home-huy/9eae6f4b-c685-4b06-ba9f-077df0d00aad/scratchpad/frames'
shutil.rmtree(FRAMES, ignore_errors=True); os.makedirs(FRAMES)
frames = []   # (path, duration)

def rd(name, a=None, b=None):
    t = open(f'{L}/{name}', errors='replace').read().replace('\r', '')
    t = re.sub(r'\x1b\[[0-9;]*m', '', t).split('\n')
    return [x for x in t][a:b]

def render(buf, caption, sub):
    im = Image.new('RGB', (W, H), (18, 20, 26))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, W, 62], fill=(31, 78, 121))
    d.text((16, 8), caption, font=BOLD, fill=(255, 255, 255))
    d.text((16, 36), sub, font=FONT, fill=(200, 220, 240))
    y = 74
    for ln in buf[-ROWS:]:
        col = (220, 220, 220)
        if ln.startswith('# '): col = (120, 200, 255)
        elif ln.startswith('$ ') or ln.startswith('(gdb) '): col = (160, 255, 160)
        elif '[ALERT]' in ln: col = (255, 190, 90)
        d.text((12, y), ln[:COLS], font=FONT, fill=col)
        y += LH
    return im

SCALE = 2.5
def emit(buf, cap, sub, dur):
    dur = dur * SCALE
    p = f'{FRAMES}/f{len(frames):05d}.png'
    render(buf, cap, sub).save(p); frames.append((p, dur))

def seg(cap, sub, items, hold=3.0):
    """items: ('cmd', text) | ('out', [lines], per_line_delay) | ('note', text)"""
    buf = []
    emit(buf, cap, sub, 1.2)
    for it in items:
        if it[0] == 'cmd':
            txt = '$ ' + it[1]
            buf.append('$ ')
            for i in range(2, len(txt) + 1, 6):
                buf[-1] = txt[:i]; emit(buf, cap, sub, 0.1)
            buf[-1] = txt; emit(buf, cap, sub, 0.5)
        elif it[0] == 'out':
            lines = it[1]; step = it[3] if len(it) > 3 else 4
            for i in range(0, len(lines), step):
                buf.extend(lines[i:i + step]); emit(buf, cap, sub, it[2])
        elif it[0] == 'note':
            buf.append('# ' + it[1]); emit(buf, cap, sub, 1.8)
    emit(buf, cap, sub, hold)

def card(title, lines, dur):
    im = Image.new('RGB', (W, H), (31, 78, 121)); d = ImageDraw.Draw(im)
    big = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf', 40)
    mid = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 24)
    d.text((60, 200), title, font=big, fill='white')
    for i, l in enumerate(lines): d.text((60, 290 + i * 40), l, font=mid, fill=(220, 235, 250))
    p = f'{FRAMES}/f{len(frames):05d}.png'; im.save(p); frames.append((p, dur))

card('ASSIGNMENT-02: Sensor Monitoring System (SMS)',
     ['Ha Anh Huy - SE203732', 'Embedded Linux Systems  |  ARMv7 QEMU vexpress-a9, kernel 5.15',
      'Demo: phat lai log that cua phien chay (QEMU / GDB / Valgrind)',
      '1) driver + /proc   2) 4 thread + SCHED_FIFO   3) SIGINT shutdown',
      '4) GDB set variable -> alert   5) Valgrind + jitter'], 7)

# --- Demo 1 ---
seg('DEMO 1/5  Kernel driver sms_sensor.ko', 'insmod, /dev/sms_sensor (misc device), /proc/sms_stats, SMS_SET_INTERVAL',
    [('cmd', 'lsmod; ls -l /dev/sms_sensor'), ('out', rd('driver_load.txt', 1, 14), 0.4),
     ('cmd', 'cat /proc/sms_stats      # truoc khi chay'), ('out', rd('proc_sms_stats_before.txt'), 0.3),
     ('note', 'moi lan read() tra ve 1 dong CSV: timestamp_ms,temperature,humidity')], 4)
# --- Demo 2 ---
st = rd('proc_status_samples.txt')
i0 = [i for i, x in enumerate(st) if x.startswith('== T=5s')][0]
seg('DEMO 2/5  4 thread chay song song, sensor thread SCHED_FIFO 50', 'sms_app -d 60 -v (QEMU), threads, fd, Vm* o T=5/30/55 s',
    [('cmd', 'sms_app -d 60 -v -l /tmp/sms.log -j /tmp/jitter.txt &'),
     ('out', rd('sms_sample_run.txt', 0, 14), 0.35),
     ('cmd', 'ls /proc/$P/task; cat /proc/$P/task/*/comm; chrt -p <tid sensor>'),
     ('out', st[i0:i0 + 26], 0.25),
     ('cmd', 'grep -E "VmSize|VmRSS" /proc/$P/status   # T=30s, T=55s'),
     ('out', [x for x in st if 'Vm' in x or x.startswith('== T=')][5:], 0.3),
     ('note', 'RSS khong tang: mlockall + buffer 64 phan tu cap phat 1 lan')], 4)
# --- Demo 3 ---
seg('DEMO 3/5  Alert + Logger + doc /proc/sms_stats sau 60 s', 'stderr alert, sms.log, read_count ~ 120',
    [('cmd', 'cat /tmp/sms_stderr.txt | head'), ('out', rd('sms_alerts_stderr.txt', 0, 8), 0.3),
     ('cmd', 'head -8 /tmp/sms.log'), ('out', rd('sms.log', 0, 8), 0.3),
     ('cmd', 'cat /proc/sms_stats      # sau 60 s, interval 500 ms'), ('out', rd('proc_sms_stats_after.txt'), 0.4),
     ('cmd', 'cat /tmp/sms_summary_stdout.txt'), ('out', rd('sms_summary_stdout.txt'), 0.25),
     ('note', 'read_count = so sample (xap xi 120 +/- 10) => dat yeu cau')], 4)
# --- Demo 4 (SIGINT) ---
sg = rd('sigint_test.txt')
seg('DEMO 4/5  Graceful shutdown khi SIGINT (Ctrl+C) + ma loi', 'tat ca thread join, log flush, exit code 0 / 1 / 2',
    [('cmd', 'sms_app -d 0 & ... sleep 8; kill -INT $P; wait $P'), ('out', sg[3:], 0.3),
     ('cmd', 'sms_app -D /dev/nonexistent -d 1; echo $?'),
     ('out', [x for x in rd('error_codes_test.txt') if 'ERROR' in x or 'exit_code' in x][:3], 0.5)], 4)
# --- Demo 5 (GDB) ---
gb = [x for x in rd('gdb_session_B.txt') if not x.startswith('warning: while') and x.strip()]
gb = [x for x in gb if not x.startswith('[New Thread')]
seg('DEMO 5a/5  GDB (kich ban B): set variable temperature=45.0', 'gdbserver trong QEMU + gdb-multiarch tren host',
    [('cmd', 'gdb-multiarch sms_app_dbg -x scenario_B.gdb      # target remote localhost:1234'),
     ('out', gb[3:60], 0.18, 3)], 4)
# --- Demo 5 (Valgrind + jitter) ---
vg = [x.replace('==', '').split(' ', 1)[-1] for x in rd('valgrind_sms.txt') if 'HEAP SUMMARY' in x or 'in use at exit' in x or 'total heap' in x or 'All heap' in x or 'ERROR SUMMARY' in x]
seg('DEMO 5b/5  Valgrind: 0 bytes definitely lost + jitter FIFO vs OTHER', 'valgrind --leak-check=full (32 s, SIGINT), jitter_report.txt',
    [('cmd', 'timeout -s INT 32 valgrind --leak-check=full ./sms_app_x86 -d 0'), ('out', vg, 0.5, 1),
     ('cmd', 'cat logs/jitter_report.txt    # SCHED_FIFO vs SCHED_OTHER, 1500 mau'),
     ('out', [x for x in rd('jitter_report.txt') if x.startswith('#####') or re.search(r'policy|samples|min_us|avg_us|max_us|p99_us|\d+us', x)][:38], 0.12, 2)], 6)
card('Ket qua tom tat', ['4 thread + driver .ko: chay 60 s, 0 crash, read_count = 121',
      'Valgrind: 0 bytes definitely lost, 0 errors; Helgrind: 0 race',
      'SIGINT: dung sach, exit code 0; loi driver: exit code 1; tham so sai: 2',
      'Jitter sensor thread QEMU: avg ~0.5 ms, p99 < 1.3 ms (SCHED_FIFO)'], 7)

lst = f'{FRAMES}/list.txt'
with open(lst, 'w') as f:
    for p, dur in frames: f.write(f"file '{p}'\nduration {dur}\n")
    f.write(f"file '{frames[-1][0]}'\n")
os.makedirs(f'{B}/demo', exist_ok=True)
out = f'{B}/demo/SE203732_demo.mp4'
subprocess.run([f'{B}/tools/ffmpeg/ffmpeg', '-y', '-loglevel', 'error', '-f', 'concat', '-safe', '0', '-i', lst,
                '-vf', 'fps=10,format=yuv420p', '-c:v', 'libx264', '-crf', '28', '-movflags', '+faststart', out], check=True)
print('frames', len(frames), 'seconds', round(sum(d for _, d in frames), 1), out, os.path.getsize(out))
